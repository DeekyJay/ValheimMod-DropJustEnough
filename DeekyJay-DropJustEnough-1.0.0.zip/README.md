# DropJustEnough - Valheim Mod
### Encumbered? Alt click on an item in your inventory. You'll drop _just enough._

You're one hour into raiding dungeons and grabbing loot. Your total weight is creeping up, when it suddenly happens. You've hit the limit.

You open your inventory and start juggling some things around, tossing things out, trying to get under the maximum weight you can carry.

Yeah, this scenario is annoying.

With this mod, just hold Alt and left click on a stack. It'll drop just enough so you're no longer encumbered.

Sprint home!

Wanna get in contact with me? Join the Valheim Discord server and shoot me a DM.

My Discord is Deek#0001